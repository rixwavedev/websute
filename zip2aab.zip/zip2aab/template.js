const fs = require('fs'), path = require('path');
const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/'/g, "\\'").replace(/"/g, '\\"');
const put = (root, rel, txt) => { const p = path.join(root, rel); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, txt); };

// Genera un progetto Android minimo: una WebView che serve TUTTO assets/www via WebViewAssetLoader (https, niente file://)
exports.writeProject = (root, o) => {
  const NS = 'http://schemas.android.com/apk/res/android';
  const url = 'https://appassets.androidplatform.net/assets/www/' + o.start.split('/').map(encodeURIComponent).join('/');
  put(root, 'settings.gradle', `pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositories { google(); mavenCentral() } }
include ':app'
rootProject.name = 'wrapper'`);
  put(root, 'build.gradle', `plugins { id 'com.android.application' version '8.9.1' apply false }`);
  put(root, 'gradle.properties', `org.gradle.jvmargs=-Xmx2g\nandroid.useAndroidX=true`);
  put(root, 'app/build.gradle', `plugins { id 'com.android.application' }
android {
  namespace '${o.packageId}'
  compileSdk 36
  defaultConfig { applicationId '${o.packageId}'; minSdk 26; targetSdk 36; versionCode ${o.versionCode}; versionName '${o.versionName}' }
  // Di default AGP scarta file nascosti (.*), cartelle _* e altri: qui nessun pattern può combaciare => nessun file escluso
  androidResources { ignoreAssetsPattern = '!__nessun_file_ignorato__' }
  signingConfigs { release {
    storeFile file(System.getenv('KS_PATH')); storePassword System.getenv('KS_PASS')
    keyAlias System.getenv('KS_ALIAS'); keyPassword System.getenv('KS_PASS') } }
  buildTypes { release { signingConfig signingConfigs.release; minifyEnabled false } }
}
dependencies { implementation 'androidx.webkit:webkit:1.12.1'; implementation 'androidx.activity:activity:1.9.3' }`);
  put(root, 'app/src/main/AndroidManifest.xml', `<manifest xmlns:android="${NS}">
  <uses-permission android:name="android.permission.INTERNET"/>
  <application android:label="@string/app_name" android:icon="@mipmap/ic_launcher" android:theme="@style/AppTheme" android:allowBackup="false">
    <activity android:name=".MainActivity" android:exported="true"
      android:configChanges="orientation|screenSize|keyboardHidden|smallestScreenSize|screenLayout|uiMode">
      <intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter>
    </activity>
  </application>
</manifest>`);
  put(root, `app/src/main/java/${o.packageId.replace(/\./g, '/')}/MainActivity.java`, `package ${o.packageId};
import android.content.Intent;
import android.os.Bundle;
import android.webkit.*;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends ComponentActivity {
  private WebView web;
  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    web = new WebView(this);
    setContentView(web);
    web.setOnApplyWindowInsetsListener((v, i) -> { v.setPadding(i.getSystemWindowInsetLeft(), i.getSystemWindowInsetTop(), i.getSystemWindowInsetRight(), i.getSystemWindowInsetBottom()); return i; });
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false); s.setAllowFileAccess(false);
    final WebViewAssetLoader loader = new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
    web.setWebViewClient(new WebViewClient() {
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) { return loader.shouldInterceptRequest(r.getUrl()); }
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        if ("appassets.androidplatform.net".equals(r.getUrl().getHost())) return false;
        startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); return true;
      }
    });
    getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
      @Override public void handleOnBackPressed() {
        if (web.canGoBack()) web.goBack(); else { setEnabled(false); getOnBackPressedDispatcher().onBackPressed(); }
      }
    });
    web.loadUrl("${url}");
  }
}`);
  put(root, 'app/src/main/res/values/strings.xml', `<resources><string name="app_name">${esc(o.appName)}</string></resources>`);
  put(root, 'app/src/main/res/values/styles.xml', `<resources><style name="AppTheme" parent="android:Theme.Material.Light.NoActionBar"/><color name="ic_bg">#1F5EFF</color></resources>`);
  put(root, 'app/src/main/res/drawable/ic_fg.xml', `<vector xmlns:android="${NS}" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108"><path android:fillColor="#FFFFFF" android:pathData="M42,34 L78,54 L42,74 Z"/></vector>`);
  put(root, 'app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml', `<adaptive-icon xmlns:android="${NS}"><background android:drawable="@color/ic_bg"/><foreground android:drawable="@drawable/ic_fg"/></adaptive-icon>`);
};
