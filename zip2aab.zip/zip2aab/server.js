const express = require('express'), multer = require('multer'), AdmZip = require('adm-zip');
const fs = require('fs'), path = require('path'), os = require('os'), crypto = require('crypto');
const { spawn } = require('child_process');
const { writeProject } = require('./template');

const app = express(), jobs = new Map();
const upload = multer({ dest: os.tmpdir(), limits: { fileSize: 400 * 1024 * 1024 } });
const MAX_UNZIPPED = 1.5 * 1024 ** 3, MAX_FILES = 50000;
let queue = Promise.resolve(); // una build alla volta: Gradle è pesante
app.use(express.static(path.join(__dirname, 'public')));

const run = (cmd, args, opts, log) => new Promise((ok, ko) => {
  const p = spawn(cmd, args, opts);
  p.stdout.on('data', d => log(d.toString())); p.stderr.on('data', d => log(d.toString()));
  p.on('error', ko); p.on('close', c => (c === 0 ? ok() : ko(new Error(`${cmd} è terminato con codice ${c}. Vedi il log.`))));
});

// Estrae TUTTO. Un percorso pericoloso blocca la build con un errore: nessun file viene scartato in silenzio.
function extractAll(zipPath, dest) {
  const files = []; let total = 0;
  for (const e of new AdmZip(zipPath).getEntries()) {
    const rel = path.posix.normalize(e.entryName.replace(/\\/g, '/'));
    if (rel === '..' || rel.startsWith('../') || path.posix.isAbsolute(rel)) throw new Error(`Percorso non sicuro nello zip: ${e.entryName}`);
    if (e.isDirectory) { fs.mkdirSync(path.join(dest, rel), { recursive: true }); continue; }
    total += e.header.size;
    if (total > MAX_UNZIPPED || files.length >= MAX_FILES) throw new Error('Lo zip supera i limiti (1,5 GB / 50.000 file).');
    const out = path.join(dest, rel);
    fs.mkdirSync(path.dirname(out), { recursive: true });
    fs.writeFileSync(out, e.getData());
    files.push(rel);
  }
  if (!files.length) throw new Error('Lo zip è vuoto.');
  return [...new Set(files)];
}

// Verifica finale: ogni file dello zip deve essere dentro l'AAB, altrimenti la build fallisce.
const missing = (aab, files) => {
  const inAab = new Set(new AdmZip(aab).getEntries().map(e => e.entryName));
  return files.filter(f => !inAab.has('base/assets/www/' + f));
};

async function build(job, p) {
  const log = s => { job.log += s; };
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'aab-'));
  try {
    const files = extractAll(p.zipPath, path.join(work, 'app/src/main/assets/www'));
    log(`Estratti ${files.length} file.\n`);
    const start = files.filter(f => /(^|\/)index\.html$/i.test(f)).sort((a, b) => a.length - b.length)[0];
    if (!start) throw new Error('Nel zip non c\'è nessun index.html: serve un\'app web (HTML/JS/CSS).');

    let ks = p.keystorePath, pass = p.storePass, alias = p.alias || 'upload';
    if (!ks) {
      ks = path.join(work, 'upload-keystore.jks'); pass = crypto.randomBytes(12).toString('hex'); alias = 'upload';
      const cn = p.appName.replace(/[^\p{L}\p{N} ]/gu, '') || 'App';
      await run('keytool', ['-genkeypair', '-keystore', ks, '-alias', alias, '-keyalg', 'RSA', '-keysize', '2048', '-validity', '10000',
        '-storepass', pass, '-keypass', pass, '-dname', `CN=${cn}, O=${cn}`], {}, log);
    }
    writeProject(work, { ...p, start });
    await run('gradle', ['--no-daemon', 'bundleRelease'], { cwd: work, env: { ...process.env, KS_PATH: ks, KS_PASS: pass, KS_ALIAS: alias } }, log);

    const aab = path.join(work, 'app/build/outputs/bundle/release/app-release.aab');
    const miss = missing(aab, files);
    if (miss.length) throw new Error(`Verifica fallita: ${miss.length} file non sono nel bundle, es. ${miss.slice(0, 5).join(', ')}`);

    const keep = path.join(os.tmpdir(), 'out-' + job.id); fs.mkdirSync(keep);
    job.aab = path.join(keep, 'app.aab'); fs.copyFileSync(aab, job.aab);
    if (!p.keystorePath) { job.ks = path.join(keep, 'upload-keystore.jks'); fs.copyFileSync(ks, job.ks); job.storePass = pass; }
    job.count = files.length; job.state = 'done';
  } finally { fs.rmSync(work, { recursive: true, force: true }); }
}

app.post('/api/build', upload.fields([{ name: 'zip', maxCount: 1 }, { name: 'keystore', maxCount: 1 }]), (req, res) => {
  const b = req.body, z = req.files?.zip?.[0], k = req.files?.keystore?.[0];
  const bad = m => { [z, k].forEach(f => f && fs.rmSync(f.path, { force: true })); res.status(400).json({ error: m }); };
  if (!z) return bad('Carica uno zip.');
  const appName = (b.appName || '').trim(), versionCode = parseInt(b.versionCode, 10) || 1, versionName = (b.versionName || '1.0').trim();
  if (!appName) return bad('Inserisci il nome dell\'app.');
  if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/i.test(b.packageId || '')) return bad('Package ID non valido (esempio: com.tuonome.gioco).');
  if (!/^[\w.\-]{1,30}$/.test(versionName)) return bad('Versione non valida.');
  if (k && !b.storePass) return bad('Inserisci la password del keystore.');

  const id = crypto.randomUUID(), job = { id, state: 'running', log: 'In coda…\n' };
  jobs.set(id, job);
  queue = queue.then(() => build(job, { zipPath: z.path, appName, packageId: b.packageId, versionCode, versionName,
      keystorePath: k?.path, storePass: b.storePass, alias: b.alias }))
    .catch(e => { job.state = 'error'; job.error = e.message; })
    .finally(() => { [z, k].forEach(f => f && fs.rmSync(f.path, { force: true }));
      setTimeout(() => { jobs.delete(id); fs.rmSync(path.join(os.tmpdir(), 'out-' + id), { recursive: true, force: true }); }, 3600e3); });
  res.json({ id });
});

const job = (req, res) => { const j = jobs.get(req.params.id); if (!j) res.status(404).json({ error: 'Sessione scaduta.' }); return j; };
app.get('/api/job/:id', (req, res) => { const j = job(req, res); if (j) res.json({ state: j.state, error: j.error, log: j.log.slice(-4000), count: j.count, storePass: j.storePass, hasKeystore: !!j.ks }); });
app.get('/api/job/:id/aab', (req, res) => { const j = job(req, res); if (j?.aab) res.download(j.aab, 'app-release.aab'); });
app.get('/api/job/:id/keystore', (req, res) => { const j = job(req, res); if (j?.ks) res.download(j.ks, 'upload-keystore.jks'); });

app.listen(process.env.PORT || 3000, () => console.log('zip2aab su :3000'));
